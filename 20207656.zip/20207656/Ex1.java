<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Hồ sơ cá nhân</title>
</head>
<body>
    <h1>Hồ sơ cá nhân</h1>
    
    <h2>Thông tin cá nhân</h2>
    <p><strong>Họ và tên:</strong> <%= fullName %></p>
    <p><strong>Email:</strong> <%= email %></p>
    <p><strong>Giới thiệu:</strong> <%= bio %></p>
    
    <h2>Ảnh cá nhân</h2>
    <img src="path/to/your/photo.jpg" alt="Ảnh cá nhân" width="300" height="300">
</body>
</html>